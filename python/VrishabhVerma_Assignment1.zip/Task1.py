num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

sum = num1 + num2
sub = num1 - num2
prod = num1 * num2
div= num1 / num2

print("The sum of", num1, "and", num2, "is:", sum)
print("The difference of", num1, "and", num2, "is:", sub)
print("The product of", num1, "and", num2, "is:", prod)
print("The quotient of", num1, "and", num2, "is:", div)